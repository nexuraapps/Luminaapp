
import React from 'react';

interface LogoProps {
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = "w-12 h-12" }) => {
  return (
    <div className={`${className} bg-black rounded-xl flex items-center justify-center border border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.2)]`}>
      <svg viewBox="0 0 100 100" className="w-2/3 h-2/3">
        <path 
          d="M30 20 V80 H70" 
          fill="none" 
          stroke="#A855F7" 
          strokeWidth="14" 
          strokeLinecap="round" 
          strokeLinejoin="round"
          className="drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]"
        />
      </svg>
    </div>
  );
};
