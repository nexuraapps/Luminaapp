
import React from 'react';
import { FitMode } from '../types';

interface PhonePreviewProps {
  videoUrl: string;
  fitMode: FitMode;
  muted: boolean;
}

export const PhonePreview: React.FC<PhonePreviewProps> = ({ videoUrl, fitMode, muted }) => {
  return (
    <div className="relative w-[280px] h-[580px] bg-black rounded-[3rem] border-8 border-neutral-800 shadow-2xl overflow-hidden ring-1 ring-purple-500/20">
      {/* Speaker Bar */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-neutral-800 rounded-b-2xl z-20"></div>
      
      {/* Video Content */}
      <video
        key={videoUrl}
        src={videoUrl}
        autoPlay
        loop
        muted={muted}
        className={`w-full h-full object-${fitMode === 'fill' ? 'fill' : fitMode === 'cover' ? 'cover' : 'contain'} transition-all duration-300`}
      />

      {/* UI Overlay Simulation */}
      <div className="absolute inset-0 z-10 p-6 flex flex-col justify-between pointer-events-none">
        <div className="mt-8">
          <div className="text-4xl font-light text-white/90">09:41</div>
          <div className="text-sm font-medium text-white/70">Monday, October 24</div>
        </div>
        
        <div className="flex justify-around mb-4 bg-white/10 backdrop-blur-md rounded-2xl p-4">
          <div className="w-10 h-10 bg-white/20 rounded-xl"></div>
          <div className="w-10 h-10 bg-white/20 rounded-xl"></div>
          <div className="w-10 h-10 bg-white/20 rounded-xl"></div>
          <div className="w-10 h-10 bg-white/20 rounded-xl"></div>
        </div>
      </div>
    </div>
  );
};
